class GalleryLayout extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            images: [
                {
                    imagename: "../assets/images/1.jpg",
                    title: "xyz",
                    description: "abc"
                },
                {
                    imagename: "../assets/images/2.jpg",
                    title: "xyz",
                    description: "abc"
                },
                {
                    imagename: "../assets/images/3.jpg",
                    title: "xyz",
                    description: "abc"
                },
                {
                    imagename: "../assets/images/4.jpg",
                    title: "xyz",
                    description: "abc"
                }
            ]

        }
    }

    render() {
        const {images}=this.state
        var arr = []
        images.forEach(item => {
            console.log("INSIDE THE FOREACH 37::::" + JSON.stringify(item))
            arr.push(
                <div className="img">
                    <a href={item.imagename}>
                        <img src={item.imagename} width="200" height="200" />
                    </a>
                    <div className="desc">{item.description} </div>
                </div>
            )
        });
        return (
            <div className="gallery">
                <div className="row">
                {arr}
                </div>
            </div>
        )
    }
}