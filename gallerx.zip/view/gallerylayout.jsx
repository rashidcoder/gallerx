class GalleryLayout extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            images: [
                {
                    path: "http://192.168.18.67/gallerx/assets/images/1.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/2.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/3.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/4.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/1.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/2.jpg",
                    title: "xyz name",
                    description: "description"
                },
                {
                    path: "http://192.168.18.67/gallerx/assets/images/3.jpg",
                    title: "xyz name",
                    description: "description"
                },
            ]

        }
    }

    render() {
        const { images } = this.state
        var arr = []
        images.forEach(item => {
            console.log("INSIDE THE FOREACH 37::::" + JSON.stringify(item))
            arr.push(
                <div className={"img"}>
                    <a href={item.path}>
                        <img src={item.path} />
                    </a>
                    <span className={"image-title"}>{item.title}</span>
                    <div className={"image-description"}>{item.description} </div>
                </div>
            )
        });
        return (
            <div className={'box-container gallery'}>
                <div className={"row"}>
                    {arr}
                </div>
            </div>
        )
    }
}