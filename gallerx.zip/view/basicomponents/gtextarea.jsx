function GTextArea(props) {
    return (
        <div className={"form-input textarea"}>
            <textarea
             {...props}
            >
            </textarea>
        </div>
    )
}
